package com.example.Oblivion.System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OblivionSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
