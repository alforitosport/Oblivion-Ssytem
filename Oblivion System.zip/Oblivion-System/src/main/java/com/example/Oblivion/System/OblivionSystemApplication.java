package com.example.Oblivion.System;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OblivionSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(OblivionSystemApplication.class, args);
	}

}
